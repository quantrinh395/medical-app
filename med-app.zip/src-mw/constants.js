const PRIVATE_KEY = "Fmg7>Ka4a$SgC]7E"

const ERR_MSGS = {
    NULL_TOKEN : "Null token was passed",
    INVALID_TOKEN : "Invalid Token",
    EXPIRED_TOKEN : "Token is expired!"
}

module.exports = {
    ERR_MSGS : ERR_MSGS,
    privateKey: PRIVATE_KEY
}
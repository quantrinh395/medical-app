# Requirements
- Nodejs newest version
# Installation
- from the root directory where package.json is located. Run from cmd : "npm i"
- Install middleware: "cd src-mw && npm i"
# Running application
- Need 2 terminals to run application. One for front-end app and the other for middleware proxy.
- from Parent directory: "npm run start"
- from src-mw: "node sever.js"
- Go to localhost:3000
# Available users:
- 1
    - username: canle
    - password: canle
- 2
    - username: doctor
    - password: doctor

# Updating user data
- Go to this file for instruction: src-mw\mockData.js

Contact me for more information, This is only sketch app, not fully functional but could be used for presentation purposes
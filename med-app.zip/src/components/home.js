import React from 'react'
import './home.css'

export const HomePage = () => {
    return (
        <div className="BlockCenter">
            <h1>Welcome to Medical Application!</h1>
        </div>
    )
}